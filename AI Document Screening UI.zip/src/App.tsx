import { useState, useEffect } from "react";

type Screen = "login" | "dashboard" | "new-screening" | "result" | "case" | "history";
type Risk = "Low" | "Medium" | "High";
type CaseStatus = "Cleared" | "Flagged" | "Under Review";

interface CaseRow {
  id: string;
  date: string;
  name: string;
  doc: string;
  nat: string;
  risk: Risk;
  score: number;
  status: CaseStatus;
}

const CASES: CaseRow[] = [
  { id: "SCR-2024-0891", date: "2024-11-14", name: "Aleksei Voronov",  doc: "Passport",    nat: "RUS", risk: "High",   score: 87, status: "Flagged" },
  { id: "SCR-2024-0890", date: "2024-11-14", name: "Priya Nair",       doc: "Visa",        nat: "IND", risk: "Low",    score: 12, status: "Cleared" },
  { id: "SCR-2024-0889", date: "2024-11-13", name: "Hamid Al-Rashidi", doc: "Passport",    nat: "JOR", risk: "Medium", score: 54, status: "Under Review" },
  { id: "SCR-2024-0888", date: "2024-11-13", name: "Lin Wei",          doc: "National ID", nat: "CHN", risk: "Low",    score:  8, status: "Cleared" },
  { id: "SCR-2024-0887", date: "2024-11-12", name: "Yusuf Musa",       doc: "Passport",    nat: "NGA", risk: "High",   score: 91, status: "Flagged" },
  { id: "SCR-2024-0886", date: "2024-11-12", name: "Emma Schreiber",   doc: "Visa",        nat: "DEU", risk: "Low",    score:  6, status: "Cleared" },
  { id: "SCR-2024-0885", date: "2024-11-11", name: "Carlos Mendez",    doc: "Passport",    nat: "MEX", risk: "Medium", score: 48, status: "Under Review" },
  { id: "SCR-2024-0884", date: "2024-11-10", name: "Fatima Al-Zahra",  doc: "National ID", nat: "MAR", risk: "Low",    score: 19, status: "Cleared" },
  { id: "SCR-2024-0883", date: "2024-11-10", name: "Ivan Petrov",      doc: "Passport",    nat: "RUS", risk: "High",   score: 79, status: "Flagged" },
  { id: "SCR-2024-0882", date: "2024-11-09", name: "Amara Diallo",     doc: "Visa",        nat: "SEN", risk: "Low",    score: 23, status: "Cleared" },
];

// ─── Shared ───────────────────────────────────────────────────────────────────

function RiskPill({ risk }: { risk: Risk }) {
  const s: Record<Risk, string> = {
    Low:    "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
    Medium: "bg-amber-50 text-amber-700 ring-1 ring-amber-200",
    High:   "bg-red-50 text-red-700 ring-1 ring-red-200",
  };
  return (
    <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold tracking-wide ${s[risk]}`}
      style={{ fontFamily: "'JetBrains Mono', monospace" }}>
      {risk.toUpperCase()}
    </span>
  );
}

function StatusPill({ status }: { status: CaseStatus }) {
  const s: Record<CaseStatus, string> = {
    Cleared:        "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
    Flagged:        "bg-red-50 text-red-700 ring-1 ring-red-200",
    "Under Review": "bg-sky-50 text-sky-700 ring-1 ring-sky-200",
  };
  return (
    <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${s[status]}`}>
      {status}
    </span>
  );
}

// ─── Top Nav ──────────────────────────────────────────────────────────────────

const NAV_LINKS = [
  { id: "dashboard",     label: "Dashboard" },
  { id: "new-screening", label: "New Screening" },
  { id: "history",       label: "Case History" },
] as const;

function TopNav({
  screen,
  go,
  menuOpen,
  setMenuOpen,
}: {
  screen: Screen;
  go: (s: Screen) => void;
  menuOpen: boolean;
  setMenuOpen: (v: boolean) => void;
}) {
  const handleNav = (id: Screen) => {
    go(id);
    setMenuOpen(false);
  };

  return (
    <header className="bg-[#0b1f40] border-b border-white/10 sticky top-0 z-50">
      {/* Main bar */}
      <div className="flex items-center justify-between px-4 sm:px-6 lg:px-8 h-14">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-base">🛂</div>
          <div>
            <p className="text-white text-sm font-bold tracking-wide leading-none"
              style={{ fontFamily: "'Work Sans', sans-serif" }}>Border Screening</p>
            <p className="text-white/35 text-[10px] tracking-widest leading-none mt-0.5"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}>SIH 26188</p>
          </div>
        </div>

        {/* Desktop nav links */}
        <nav className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map(n => (
            <button key={n.id} onClick={() => handleNav(n.id as Screen)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                screen === n.id
                  ? "bg-white/15 text-white"
                  : "text-white/55 hover:text-white/90 hover:bg-white/8"
              }`}>
              {n.label}
            </button>
          ))}
        </nav>

        {/* Desktop officer pill */}
        <div className="hidden md:flex items-center gap-2 bg-white/8 border border-white/10 px-3 py-1.5 rounded-lg">
          <div className="w-6 h-6 rounded-full bg-blue-500/40 flex items-center justify-center text-xs text-white font-bold">K</div>
          <div>
            <p className="text-white/80 text-xs font-medium leading-none">K. Sharma</p>
            <p className="text-white/30 text-[10px] leading-none mt-0.5"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}>OFF-2841</p>
          </div>
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="md:hidden flex flex-col justify-center items-center w-9 h-9 rounded-lg hover:bg-white/10 transition-colors gap-1.5"
          aria-label="Toggle menu">
          <span className={`block w-5 h-0.5 bg-white/70 transition-transform duration-200 origin-center ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
          <span className={`block w-5 h-0.5 bg-white/70 transition-opacity duration-200 ${menuOpen ? "opacity-0" : ""}`} />
          <span className={`block w-5 h-0.5 bg-white/70 transition-transform duration-200 origin-center ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
        </button>
      </div>

      {/* Mobile dropdown */}
      {menuOpen && (
        <div className="md:hidden border-t border-white/10 bg-[#0b1f40] px-4 pb-4 pt-2">
          <nav className="space-y-1">
            {NAV_LINKS.map(n => (
              <button key={n.id} onClick={() => handleNav(n.id as Screen)}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  screen === n.id
                    ? "bg-white/15 text-white"
                    : "text-white/60 hover:bg-white/8 hover:text-white/90"
                }`}>
                {n.label}
              </button>
            ))}
          </nav>
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-blue-500/40 flex items-center justify-center text-xs text-white font-bold">K</div>
            <div>
              <p className="text-white/80 text-xs font-medium">Officer K. Sharma</p>
              <p className="text-white/35 text-[10px]"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}>OFF-2841</p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

// ─── Shell ────────────────────────────────────────────────────────────────────

function Shell({
  screen, go, children,
}: {
  screen: Screen; go: (s: Screen) => void; children: React.ReactNode;
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  // Close menu on resize to desktop
  useEffect(() => {
    const handler = () => { if (window.innerWidth >= 768) setMenuOpen(false); };
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, []);

  return (
    <div className="min-h-full flex flex-col bg-slate-50">
      <TopNav screen={screen} go={go} menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6">{children}</main>
    </div>
  );
}

// ─── 1. LOGIN ─────────────────────────────────────────────────────────────────

function Login({ go }: { go: (s: Screen) => void }) {
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");

  return (
    <div className="min-h-full bg-slate-50 flex flex-col">
      <div className="h-14 bg-[#0b1f40] flex items-center px-4 sm:px-8 gap-3">
        <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-base">🛂</div>
        <span className="text-white text-sm font-bold tracking-wide"
          style={{ fontFamily: "'Work Sans', sans-serif" }}>BORDER SCREENING SYSTEM</span>
        <span className="text-white/30 text-[10px] tracking-widest hidden sm:block"
          style={{ fontFamily: "'JetBrains Mono', monospace" }}>SIH 26188</span>
      </div>

      <div className="flex-1 flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-sm">
          <div className="mb-8">
            <div className="w-11 h-11 rounded-xl bg-[#0b1f40] flex items-center justify-center mb-5 text-lg">🛂</div>
            <h1 className="text-2xl font-semibold text-slate-900"
              style={{ fontFamily: "'Work Sans', sans-serif" }}>Officer Sign In</h1>
            <p className="text-sm text-slate-500 mt-1">AI-Based Fake Identity &amp; Document Screening</p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-1.5">
                Officer ID
              </label>
              <input value={id} onChange={e => setId(e.target.value)} placeholder="e.g. OFF-2841"
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm
                  focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500
                  placeholder:text-slate-300"
                style={{ fontFamily: "'JetBrains Mono', monospace" }} />
            </div>
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-1.5">
                Password
              </label>
              <input type="password" value={pw} onChange={e => setPw(e.target.value)} placeholder="••••••••"
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm
                  focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500
                  placeholder:text-slate-300" />
            </div>
            <button onClick={() => go("dashboard")}
              className="w-full bg-[#0b1f40] hover:bg-[#16305e] text-white font-semibold
                py-2.5 rounded-xl text-sm transition-colors">
              Sign In
            </button>
          </div>
          <p className="text-center text-[11px] text-slate-400 mt-5">
            Restricted access — authorised personnel only
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── 2. DASHBOARD ────────────────────────────────────────────────────────────

function Dashboard({ go }: { go: (s: Screen) => void }) {
  const stats = [
    { label: "Total Screenings", value: "1,247", note: "All time",  color: "text-slate-900" },
    { label: "Low Risk",         value: "891",   note: "71.4%",     color: "text-emerald-600" },
    { label: "Medium Risk",      value: "243",   note: "19.5%",     color: "text-amber-600" },
    { label: "High Risk",        value: "113",   note: "9.1%",      color: "text-red-600" },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Page header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold text-slate-900"
            style={{ fontFamily: "'Work Sans', sans-serif" }}>Dashboard</h1>
          <p className="text-sm text-slate-400 mt-0.5">Thursday, 14 November 2024</p>
        </div>
        <button onClick={() => go("new-screening")}
          className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold
            px-4 py-2 rounded-xl transition-colors self-start sm:self-auto">
          + New Screening
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {stats.map(s => (
          <div key={s.label} className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-2 leading-tight">{s.label}</p>
            <p className={`text-3xl font-bold ${s.color}`}
              style={{ fontFamily: "'JetBrains Mono', monospace" }}>{s.value}</p>
            <p className="text-xs text-slate-400 mt-1">{s.note}</p>
          </div>
        ))}
      </div>

      {/* Today + Pending */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5">
          <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-4">Today's Activity</p>
          <div className="grid grid-cols-3 gap-3">
            {[{ l: "Screened", v: "34" }, { l: "Flagged", v: "4" }, { l: "Cleared", v: "28" }].map(x => (
              <div key={x.l} className="border border-slate-100 rounded-xl p-4 text-center">
                <p className="text-2xl font-bold text-slate-900"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}>{x.v}</p>
                <p className="text-xs text-slate-400 mt-1">{x.l}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Pending Review</p>
          <div className="space-y-2">
            {CASES.filter(c => c.status === "Under Review").map(c => (
              <button key={c.id} onClick={() => go("case")}
                className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl
                  border border-slate-100 hover:border-blue-200 hover:bg-blue-50/40 transition-colors text-left">
                <span className="text-xs text-blue-600"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.id.replace("SCR-2024-", "#")}</span>
                <RiskPill risk={c.risk} />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Recent cases */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-100">
          <h2 className="text-sm font-semibold text-slate-800">Recent Cases</h2>
          <button onClick={() => go("history")} className="text-xs text-blue-600 hover:underline">View all →</button>
        </div>

        {/* Scrollable table wrapper */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[600px]">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/60">
                {["Case ID", "Date", "Name", "Document", "Risk", "Score", "Status"].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-[11px] font-semibold uppercase tracking-widest text-slate-400">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {CASES.slice(0, 5).map(c => (
                <tr key={c.id} onClick={() => go("case")}
                  className="border-b border-slate-100 hover:bg-blue-50/30 cursor-pointer transition-colors">
                  <td className="px-5 py-3 text-blue-600 text-xs"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.id}</td>
                  <td className="px-5 py-3 text-slate-400 text-xs"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.date}</td>
                  <td className="px-5 py-3 font-medium text-slate-800 whitespace-nowrap">{c.name}</td>
                  <td className="px-5 py-3 text-slate-500">{c.doc}</td>
                  <td className="px-5 py-3"><RiskPill risk={c.risk} /></td>
                  <td className="px-5 py-3 font-semibold text-slate-800"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.score}</td>
                  <td className="px-5 py-3"><StatusPill status={c.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── 3. NEW SCREENING ─────────────────────────────────────────────────────────

function NewScreening({ go }: { go: (s: Screen) => void }) {
  const [docType, setDocType] = useState("Passport");
  const [uploaded, setUploaded] = useState(false);

  const checks = [
    "OCR Text Extraction", "MRZ / Barcode Validation",
    "Tampering Detection", "Face Verification",
    "Cross-Document Consistency", "Security Feature Analysis",
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-900"
          style={{ fontFamily: "'Work Sans', sans-serif" }}>New Screening</h1>
        <p className="text-sm text-slate-400 mt-0.5">Upload a travel document to begin AI-assisted verification.</p>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-5">
        <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Document Type</p>
        <div className="flex flex-wrap gap-2">
          {["Passport", "Visa", "National ID"].map(t => (
            <button key={t} onClick={() => setDocType(t)}
              className={`px-4 py-2 rounded-xl border text-sm font-medium transition-colors ${
                docType === t
                  ? "border-blue-500 bg-blue-50 text-blue-700"
                  : "border-slate-200 text-slate-600 hover:border-slate-300"
              }`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Upload */}
        <div onClick={() => setUploaded(v => !v)}
          className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center
            text-center cursor-pointer transition-all min-h-[200px] ${
            uploaded
              ? "border-emerald-400 bg-emerald-50/40"
              : "border-slate-200 hover:border-blue-300 hover:bg-blue-50/20 bg-white"
          }`}>
          {uploaded ? (
            <>
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 text-xl mb-3">✓</div>
              <p className="text-sm font-medium text-emerald-700">File Uploaded</p>
              <p className="text-xs text-slate-400 mt-1"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}>passport_scan.jpg</p>
              <button onClick={e => { e.stopPropagation(); setUploaded(false); }}
                className="text-xs text-slate-400 hover:text-red-500 mt-3 transition-colors">Remove</button>
            </>
          ) : (
            <>
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 text-xl mb-3">↑</div>
              <p className="text-sm font-medium text-slate-700">Upload Document</p>
              <p className="text-xs text-slate-400 mt-1">Click to browse or drag & drop</p>
              <p className="text-xs text-slate-300 mt-3">JPG · PNG · PDF · max 10 MB</p>
            </>
          )}
        </div>

        {/* Preview */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl flex flex-col min-h-[200px]">
          {uploaded ? (
            <div className="p-4 flex-1">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Preview</p>
              <div className="bg-white border border-slate-200 rounded-xl p-3 space-y-2">
                <div className="flex gap-3">
                  <div className="w-12 h-16 bg-slate-100 rounded-lg flex items-center justify-center text-[10px] text-slate-400">Photo</div>
                  <div className="flex-1 space-y-2 pt-1">
                    <div className="h-2 bg-slate-200 rounded w-3/4" />
                    <div className="h-2 bg-slate-200 rounded w-1/2" />
                    <div className="h-2 bg-slate-200 rounded w-2/3" />
                  </div>
                </div>
                <div className="border-t border-slate-100 pt-2 space-y-1.5">
                  <div className="h-1.5 bg-slate-200 rounded w-full" />
                  <div className="h-1.5 bg-red-200 rounded w-full" />
                </div>
                <p className="text-[10px] text-red-400 text-right">⚠ MRZ anomaly detected</p>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <p className="text-xs text-slate-300">Preview after upload</p>
            </div>
          )}
        </div>
      </div>

      {uploaded && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Screening Checks</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {checks.map(c => (
              <div key={c} className="flex items-center gap-2 text-xs text-slate-600">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                {c}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex flex-wrap gap-3">
        <button disabled={!uploaded} onClick={() => go("result")}
          className="bg-[#0b1f40] hover:bg-[#16305e] disabled:bg-slate-300 disabled:cursor-not-allowed
            text-white text-sm font-semibold px-5 py-2.5 rounded-xl transition-colors">
          Start Screening
        </button>
        <button onClick={() => go("dashboard")}
          className="border border-slate-200 text-slate-600 text-sm px-4 py-2.5 rounded-xl
            hover:bg-slate-50 transition-colors">
          Cancel
        </button>
      </div>
    </div>
  );
}

// ─── 4. SCREENING RESULT ─────────────────────────────────────────────────────

type AccKey = "ocr" | "validation" | "tampering" | "face" | "cross";

function ScreeningResult({ go }: { go: (s: Screen) => void }) {
  const [expanded, setExpanded] = useState<Record<AccKey, boolean>>({
    ocr: true, validation: false, tampering: false, face: false, cross: false,
  });
  const toggle = (k: AccKey) => setExpanded(p => ({ ...p, [k]: !p[k] }));

  const sections: { key: AccKey; label: string; summary: string; pass: boolean | null }[] = [
    { key: "ocr",        label: "OCR Extraction",             summary: "10 fields extracted — 2 anomalies flagged",    pass: null  },
    { key: "validation", label: "Document Validation",        summary: "MRZ checksum failure on line 2",               pass: false },
    { key: "tampering",  label: "Tampering Analysis",         summary: "Digital manipulation in photo zone",           pass: false },
    { key: "face",       label: "Face Verification",          summary: "Match confidence 61.3% — threshold 85%",       pass: false },
    { key: "cross",      label: "Cross-Document Verification",summary: "DOB inconsistency across passport and visa",   pass: false },
  ];

  const ocrFields = [
    { f: "Surname",       v: "VORONOV",              flag: false },
    { f: "Given Names",   v: "ALEKSEI",              flag: false },
    { f: "Nationality",   v: "RUS",                  flag: false },
    { f: "Date of Birth", v: "22 Mar 1984",          flag: false },
    { f: "Expiry Date",   v: "15 Aug 2029",          flag: false },
    { f: "Personal No.",  v: "X29-441-RU",           flag: true  },
    { f: "MRZ Line 1",    v: "P<RUSVORONOV<ALEKSEI", flag: false },
    { f: "MRZ Line 2",    v: "7004821XK8 ✗",        flag: true  },
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm flex-wrap">
        <button onClick={() => go("dashboard")} className="text-slate-400 hover:text-blue-600">Dashboard</button>
        <span className="text-slate-300">/</span>
        <span className="text-slate-700 font-medium">Screening Result</span>
        <span className="text-slate-400 text-xs ml-1"
          style={{ fontFamily: "'JetBrains Mono', monospace" }}>SCR-2024-0891</span>
      </div>

      {/* Risk banner */}
      <div className="bg-red-50 border border-red-200 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-widest text-red-400 mb-1">Overall Risk Score</p>
          <p className="text-6xl font-bold text-red-600 leading-none"
            style={{ fontFamily: "'JetBrains Mono', monospace" }}>87</p>
          <p className="text-xs text-slate-400 mt-1">out of 100</p>
        </div>
        <div className="flex flex-col gap-2 sm:text-right">
          <div className="inline-flex items-center gap-2 bg-red-100 border border-red-200 px-3 py-1.5 rounded-xl self-start sm:self-end">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            <span className="text-sm font-bold text-red-700 tracking-wide">HIGH RISK</span>
          </div>
          <span className="text-xs text-slate-500">4 of 5 checks failed</span>
          <span className="text-xs text-slate-400">AI confidence: 94.2%</span>
        </div>
      </div>

      {/* Document info */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5">
        <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-4">Document Information</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-4 gap-x-6 text-sm">
          {[
            { l: "Type",            v: "Passport" },
            { l: "Issuing Country", v: "Russia" },
            { l: "Document No.",    v: "700-4821-XK" },
            { l: "Holder Name",     v: "Aleksei Voronov" },
            { l: "Date of Birth",   v: "22 Mar 1984" },
            { l: "Expiry",          v: "15 Aug 2029" },
          ].map(item => (
            <div key={item.l}>
              <p className="text-xs text-slate-400 mb-0.5">{item.l}</p>
              <p className="font-medium text-slate-900"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}>{item.v}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Accordion */}
      <div className="space-y-2">
        {sections.map(sec => (
          <div key={sec.key} className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <button onClick={() => toggle(sec.key)}
              className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/60 transition-colors text-left gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <span className={`w-2 h-2 rounded-full shrink-0 ${
                  sec.pass === false ? "bg-red-500" : sec.pass === true ? "bg-emerald-500" : "bg-slate-300"
                }`} />
                <span className="text-sm font-semibold text-slate-800 truncate">{sec.label}</span>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs text-slate-400 hidden sm:block">{sec.summary}</span>
                <span className="text-slate-300 text-xs">{expanded[sec.key] ? "▲" : "▼"}</span>
              </div>
            </button>
            {expanded[sec.key] && (
              <div className="border-t border-slate-100 bg-slate-50/50 px-5 py-4">
                {sec.key === "ocr" ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {ocrFields.map(row => (
                      <div key={row.f}
                        className={`flex justify-between items-center px-3 py-2 rounded-xl border text-xs ${
                          row.flag ? "border-red-200 bg-red-50" : "border-slate-100 bg-white"
                        }`}>
                        <span className="text-slate-500">{row.f}</span>
                        <span className={`font-medium ${row.flag ? "text-red-600" : "text-slate-900"}`}
                          style={{ fontFamily: "'JetBrains Mono', monospace" }}>{row.v}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2 text-xs text-slate-600">
                    <div className="flex gap-2 items-start">
                      <span className="text-red-500 mt-0.5 shrink-0">▸</span>
                      <span>{sec.summary}</span>
                    </div>
                    <div className="flex gap-2 items-start">
                      <span className="text-red-500 mt-0.5 shrink-0">▸</span>
                      <span>Manual officer review is recommended for this document.</span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Key risk reasons */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5">
        <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Key Risk Reasons</p>
        <div className="space-y-2">
          {[
            "MRZ checksum failure on line 2 — document may be forged or altered.",
            "Digital manipulation artifacts detected in the passport photo zone.",
            "Face match confidence 61.3% — well below the 85% acceptance threshold.",
            "Date of birth is inconsistent between the passport and the supporting visa.",
          ].map((r, i) => (
            <div key={i} className="flex gap-3 p-3 bg-red-50 border border-red-100 rounded-xl text-sm">
              <span className="text-red-400 font-bold shrink-0"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}>{i + 1}.</span>
              <span className="text-slate-700">{r}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended action */}
      <div className="bg-[#0b1f40] rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-white/50 text-[11px] font-semibold uppercase tracking-widest mb-1">Recommended Action</p>
          <p className="text-white text-base font-semibold">Detain for Secondary Inspection</p>
          <p className="text-white/40 text-xs mt-1">All checks warrant escalation per SOP-7.3</p>
        </div>
        <button onClick={() => go("case")}
          className="bg-white hover:bg-blue-50 text-[#0b1f40] text-sm font-semibold px-4 py-2
            rounded-xl transition-colors self-start sm:self-auto shrink-0">
          Open Case →
        </button>
      </div>
    </div>
  );
}

// ─── 5. CASE DETAILS ─────────────────────────────────────────────────────────

function CaseDetails({ go }: { go: (s: Screen) => void }) {
  const [decision, setDecision] = useState("");
  const [notes, setNotes] = useState("");
  const [done, setDone] = useState(false);

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3 flex-wrap">
          <button onClick={() => go("result")} className="text-sm text-slate-400 hover:text-blue-600">← Back</button>
          <h1 className="text-xl font-semibold text-slate-900"
            style={{ fontFamily: "'Work Sans', sans-serif" }}>Case Details</h1>
          <span className="text-slate-400 text-xs"
            style={{ fontFamily: "'JetBrains Mono', monospace" }}>SCR-2024-0891</span>
          <RiskPill risk="High" />
        </div>
        <span className="text-xs text-slate-400"
          style={{ fontFamily: "'JetBrains Mono', monospace" }}>2024-11-14 · 09:41 UTC</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        {/* Left */}
        <div className="lg:col-span-3 space-y-4">
          {/* Document preview */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Document Preview</p>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="flex gap-4">
                <div className="w-14 h-18 bg-slate-200 rounded-xl flex items-center justify-center text-xs text-slate-400">Photo</div>
                <div className="flex-1 space-y-2 pt-1">
                  <div className="h-2.5 bg-slate-200 rounded w-3/4" />
                  <div className="h-2.5 bg-slate-200 rounded w-1/2" />
                  <div className="h-2.5 bg-slate-200 rounded w-2/3" />
                </div>
              </div>
              <div className="border-t border-slate-200 pt-3 space-y-1.5">
                <div className="h-2 bg-slate-200 rounded w-full" />
                <div className="h-2 bg-red-200 rounded w-full" />
              </div>
              <p className="text-[10px] text-red-500 text-right">⚠ Anomaly in MRZ row 2</p>
            </div>
          </div>

          {/* Extracted info */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Extracted Information</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-xs">
              {[
                { l: "Full Name",     v: "Aleksei Voronov" },
                { l: "Nationality",   v: "RUS" },
                { l: "Document No.", v: "700-4821-XK" },
                { l: "Date of Birth",v: "22 Mar 1984" },
                { l: "Issue Date",   v: "15 Aug 2019" },
                { l: "Expiry Date",  v: "15 Aug 2029" },
              ].map(item => (
                <div key={item.l} className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="text-slate-400">{item.l}</span>
                  <span className="font-medium text-slate-900"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{item.v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tampering evidence */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Tampering Evidence</p>
            <div className="space-y-2">
              {[
                { zone: "Photo Zone",     finding: "Digital manipulation — pixel inconsistency detected", risk: "High" as Risk },
                { zone: "MRZ Line 2",     finding: "Checksum mismatch — field value does not validate",  risk: "High" as Risk },
                { zone: "Laminate Layer", finding: "UV response anomaly in upper-right quadrant",        risk: "Medium" as Risk },
              ].map(e => (
                <div key={e.zone}
                  className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 p-3 rounded-xl border border-slate-100 text-xs">
                  <div>
                    <p className="font-semibold text-slate-800"
                      style={{ fontFamily: "'JetBrains Mono', monospace" }}>{e.zone}</p>
                    <p className="text-slate-500 mt-0.5">{e.finding}</p>
                  </div>
                  <RiskPill risk={e.risk} />
                </div>
              ))}
            </div>
          </div>

          {/* Face match */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Face Match Analysis</p>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
              <div className="flex gap-3">
                {["Document", "Live Capture"].map(label => (
                  <div key={label} className="text-center">
                    <div className="w-16 h-20 bg-slate-100 rounded-xl flex items-center justify-center text-xs text-slate-400 mb-1">
                      {label === "Document" ? "Doc" : "Live"}
                    </div>
                    <p className="text-[10px] text-slate-400">{label}</p>
                  </div>
                ))}
              </div>
              <div>
                <p className="text-4xl font-bold text-red-600 leading-none"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}>61.3%</p>
                <p className="text-xs text-slate-400 mt-1">Match confidence</p>
                <div className="mt-2 text-xs text-red-600 bg-red-50 border border-red-200 rounded-xl px-2.5 py-1.5">
                  Below 85% threshold — identity mismatch likely
                </div>
              </div>
            </div>
          </div>

          {/* Cross-doc mismatches */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Cross-Document Mismatches</p>
            <div className="space-y-2">
              {[
                { field: "Date of Birth",    d1: "22 Mar 1984",  d2: "15 Jun 1984",        docs: "Passport vs. Visa" },
                { field: "Issuing Authority",d1: "Moscow MVD",   d2: "St. Petersburg MVD", docs: "Passport vs. Police Certificate" },
              ].map(m => (
                <div key={m.field} className="p-3 rounded-xl border border-amber-200 bg-amber-50 text-xs">
                  <p className="font-semibold text-slate-800 mb-1">
                    {m.field} <span className="font-normal text-slate-400">— {m.docs}</span>
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <span className="text-slate-500">Doc 1: <span className="font-medium text-slate-800"
                      style={{ fontFamily: "'JetBrains Mono', monospace" }}>{m.d1}</span></span>
                    <span className="text-slate-500">Doc 2: <span className="font-medium text-red-600"
                      style={{ fontFamily: "'JetBrains Mono', monospace" }}>{m.d2}</span></span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right */}
        <div className="lg:col-span-2 space-y-4">
          {/* Risk summary */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Risk Summary</p>
            <div className="space-y-2.5">
              {[
                { l: "Risk Score",    v: "87 / 100", c: "text-red-600" },
                { l: "Risk Level",    v: "High",     c: "text-red-600" },
                { l: "Checks Failed", v: "4 of 5",   c: "text-red-600" },
                { l: "AI Confidence", v: "94.2%",    c: "text-slate-900" },
              ].map(r => (
                <div key={r.l} className="flex justify-between items-center text-xs border-b border-slate-100 pb-2">
                  <span className="text-slate-400">{r.l}</span>
                  <span className={`font-bold ${r.c}`}
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{r.v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Risk factors */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Risk Factors</p>
            <div className="space-y-2 text-xs text-slate-600">
              {[
                "MRZ checksum failure",
                "Photo zone manipulation detected",
                "Face match below acceptance threshold",
                "DOB inconsistency across documents",
              ].map((f, i) => (
                <div key={i} className="flex gap-2 items-start">
                  <span className="text-red-400 shrink-0 mt-0.5">▸</span>
                  <span>{f}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Officer decision */}
          <div className={`border rounded-2xl p-5 ${done ? "bg-emerald-50 border-emerald-200" : "bg-white border-slate-200"}`}>
            <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-3">Officer Decision</p>
            {done ? (
              <div className="text-center py-4">
                <p className="text-emerald-500 text-3xl mb-2">✓</p>
                <p className="text-sm font-semibold text-emerald-700">Decision Recorded</p>
                <p className="text-xs text-slate-500 mt-1"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}>{decision}</p>
                {notes && <p className="text-xs text-slate-400 mt-2 italic">"{notes}"</p>}
              </div>
            ) : (
              <div className="space-y-3">
                <div className="space-y-1.5">
                  {["Detain — Secondary Inspection", "Deny Entry", "Clear — Allow Entry", "Escalate to Supervisor"].map(opt => (
                    <label key={opt}
                      className={`flex items-center gap-2.5 text-xs cursor-pointer p-2 rounded-xl transition-colors ${
                        decision === opt ? "bg-blue-50" : "hover:bg-slate-50"
                      }`}>
                      <input type="radio" name="decision" value={opt}
                        checked={decision === opt} onChange={() => setDecision(opt)}
                        className="accent-blue-600" />
                      <span className={decision === opt ? "text-slate-900 font-medium" : "text-slate-600"}>{opt}</span>
                    </label>
                  ))}
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1.5">Officer Notes</p>
                  <textarea rows={3} value={notes} onChange={e => setNotes(e.target.value)}
                    placeholder="Add remarks for the record..."
                    className="w-full text-xs border border-slate-200 rounded-xl p-2.5 resize-none
                      focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500
                      placeholder:text-slate-300" />
                </div>
                <button disabled={!decision} onClick={() => setDone(true)}
                  className="w-full bg-[#0b1f40] hover:bg-[#16305e] disabled:bg-slate-200
                    disabled:cursor-not-allowed text-white text-xs font-semibold py-2.5
                    rounded-xl transition-colors">
                  Submit Decision
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── 6. HISTORY ──────────────────────────────────────────────────────────────

function History({ go }: { go: (s: Screen) => void }) {
  const [search, setSearch] = useState("");
  const [riskF, setRiskF] = useState<Risk | "All">("All");
  const [statusF, setStatusF] = useState<CaseStatus | "All">("All");

  const rows = CASES.filter(c => {
    const q = search.toLowerCase();
    const matchQ = !q || c.id.toLowerCase().includes(q) || c.name.toLowerCase().includes(q) || c.nat.toLowerCase().includes(q);
    const matchR = riskF === "All" || c.risk === riskF;
    const matchS = statusF === "All" || c.status === statusF;
    return matchQ && matchR && matchS;
  });

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold text-slate-900"
            style={{ fontFamily: "'Work Sans', sans-serif" }}>Case History</h1>
          <p className="text-sm text-slate-400 mt-0.5">{CASES.length} total cases on record</p>
        </div>
        <button onClick={() => go("new-screening")}
          className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold
            px-4 py-2 rounded-xl transition-colors self-start sm:self-auto">
          + New Screening
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-wrap gap-4 items-end">
        <div className="flex-1 min-w-[200px]">
          <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-1.5">Search</p>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Case ID, name, nationality..."
            className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm
              focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500" />
        </div>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-1.5">Risk Level</p>
          <select value={riskF} onChange={e => setRiskF(e.target.value as Risk | "All")}
            className="border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white
              focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500">
            {["All", "Low", "Medium", "High"].map(v => <option key={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mb-1.5">Status</p>
          <select value={statusF} onChange={e => setStatusF(e.target.value as CaseStatus | "All")}
            className="border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white
              focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500">
            {["All", "Cleared", "Flagged", "Under Review"].map(v => <option key={v}>{v}</option>)}
          </select>
        </div>
        {(search || riskF !== "All" || statusF !== "All") && (
          <button onClick={() => { setSearch(""); setRiskF("All"); setStatusF("All"); }}
            className="border border-slate-200 text-slate-500 text-xs px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors">
            Clear
          </button>
        )}
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-100">
                {["Case ID", "Date", "Name", "Nat.", "Document", "Risk", "Score", "Status", ""].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-[11px] font-semibold uppercase tracking-widest text-slate-400 whitespace-nowrap">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-14 text-sm text-slate-300">No cases match your filters.</td>
                </tr>
              ) : rows.map(c => (
                <tr key={c.id} className="border-b border-slate-100 hover:bg-blue-50/25 transition-colors">
                  <td className="px-5 py-3 text-blue-600 text-xs"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.id}</td>
                  <td className="px-5 py-3 text-slate-400 text-xs"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.date}</td>
                  <td className="px-5 py-3 font-medium text-slate-800 whitespace-nowrap">{c.name}</td>
                  <td className="px-5 py-3 text-slate-400 text-xs"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.nat}</td>
                  <td className="px-5 py-3 text-slate-500">{c.doc}</td>
                  <td className="px-5 py-3"><RiskPill risk={c.risk} /></td>
                  <td className="px-5 py-3 font-bold text-slate-800"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.score}</td>
                  <td className="px-5 py-3"><StatusPill status={c.status} /></td>
                  <td className="px-5 py-3">
                    <button onClick={() => go("case")}
                      className="text-xs text-blue-600 hover:underline whitespace-nowrap">View →</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2">
          <span className="text-xs text-slate-400">Showing {rows.length} of {CASES.length} cases</span>
          <div className="flex gap-1">
            {[1, 2, 3].map(p => (
              <button key={p}
                className={`w-7 h-7 text-xs rounded-lg border transition-colors ${
                  p === 1
                    ? "border-blue-500 bg-blue-50 text-blue-600 font-semibold"
                    : "border-slate-200 text-slate-400 hover:border-blue-300"
                }`}>
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("login");

  if (screen === "login") return <Login go={setScreen} />;

  return (
    <Shell screen={screen} go={setScreen}>
      {screen === "dashboard"     && <Dashboard       go={setScreen} />}
      {screen === "new-screening" && <NewScreening    go={setScreen} />}
      {screen === "result"        && <ScreeningResult go={setScreen} />}
      {screen === "case"          && <CaseDetails     go={setScreen} />}
      {screen === "history"       && <History         go={setScreen} />}
    </Shell>
  );
}
